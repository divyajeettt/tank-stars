# About tank-stars

tank-stars is a clone of the popular mobile game, Tank Stars, built in Java.

## Note

The attached GitHub repo link is the repo of our project. The repo is currently private. If you would like to view the code there, please let us know so that we can add you as collaborators.
